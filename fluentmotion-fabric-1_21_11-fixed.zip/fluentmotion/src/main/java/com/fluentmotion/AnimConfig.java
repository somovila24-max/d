package com.fluentmotion;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Настройки лежат в config/fluentmotion.json (создаётся при первом запуске). */
public final class AnimConfig {
    public static AnimConfig C = new AnimConfig();

    public boolean enabled = true;
    public boolean gait = true;       // новая ходьба/бег
    public boolean turning = true;    // наклон в поворотах + шаги на месте
    public boolean jumping = true;    // прыжки, падение, приземление
    public boolean footIk = true;     // ноги по высоте блоков
    public boolean wallArms = true;   // отодвигание рук от стен

    public float footIkStrength = 1.0f;
    public float pelvisFactor = 0.75f;   // насколько таз опускается к нижней ноге (0..1)
    public float maxLegLiftDeg = 70f;    // максимум подъёма ноги на ступеньку
    public float gaitDip = 0.5f;         // приседание таза в фазе шага
    public float wallBodyShiftPx = 2.0f; // сдвиг тела от стены (пиксели модели)
    public float wallArmTuckPx = 1.0f;   // прижатие руки к телу

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static void load() {
        Path f = FabricLoader.getInstance().getConfigDir().resolve("fluentmotion.json");
        try {
            if (Files.exists(f)) {
                AnimConfig loaded = GSON.fromJson(Files.readString(f), AnimConfig.class);
                if (loaded != null) C = loaded;
            }
            Files.writeString(f, GSON.toJson(C)); // дописывает новые поля
        } catch (Exception e) {
            System.err.println("[FluentMotion] config error: " + e);
        }
    }
}
