package com.fluentmotion;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.PlayerLikeEntity;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPose;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Считает скорость, поворот, высоту земли под ногами и близость стен. Вызывается раз в кадр на игрока. */
public final class AnimSolver {
    private static final Map<UUID, AnimData> DATA = new HashMap<>();
    private static int counter;

    public static AnimData update(PlayerLikeEntity p, PlayerEntityRenderState st, float td) {
        AnimConfig c = AnimConfig.C;
        AnimData d = DATA.computeIfAbsent(p.getUuid(), k -> new AnimData());
        long now = System.nanoTime();
        d.lastSeen = now;
        if (++counter % 600 == 0) DATA.values().removeIf(x -> now - x.lastSeen > 10_000_000_000L);

        EntityPose pose = p.getPose();
        d.active = (pose == EntityPose.STANDING || pose == EntityPose.CROUCHING)
                && !p.hasVehicle() && !p.isSpectator() && !p.isClimbing()
                && !p.isTouchingWater() && !p.isDead();
        d.sneaking = p.isInSneakingPose();
        d.usingItem = p.isUsingItem();
        d.swing = p.getHandSwingProgress(td);
        d.onGround = p.isOnGround();

        Vec3d pos = p.getLerpedPos(td);
        if (d.lastNanos == 0) {
            d.lx = pos.x; d.ly = pos.y; d.lz = pos.z; d.lastYaw = st.bodyYaw; d.lastNanos = now;
            return d;
        }
        float dt = (now - d.lastNanos) / 1e9f;
        if (dt < 0.002f) return d;               // тот же кадр, не пересчитываем
        d.lastNanos = now;
        dt = Math.min(dt, 0.1f);

        // --- скорости ---
        double dx = pos.x - d.lx, dy = pos.y - d.ly, dz = pos.z - d.lz;
        if (dx * dx + dy * dy + dz * dz > 25) {   // телепорт
            d.speed = 0; d.vy = 0; d.yawRate = 0;
        } else {
            float sp = (float) Math.sqrt(dx * dx + dz * dz) / dt;
            d.speed = approach(d.speed, Math.min(sp, 14f), 18f, dt);
            d.vy = approach(d.vy, MathHelper.clamp((float) dy / dt, -60f, 30f), 18f, dt);
            float dyaw = MathHelper.wrapDegrees(st.bodyYaw - d.lastYaw);
            d.yawRate = approach(d.yawRate, MathHelper.clamp(dyaw / dt, -1080f, 1080f), 16f, dt);
            d.turnPhase += Math.abs(dyaw) * (float) Math.PI / 40f;
        }
        d.lx = pos.x; d.ly = pos.y; d.lz = pos.z; d.lastYaw = st.bodyYaw;

        d.move = approach(d.move, MathHelper.clamp(d.speed / 4f, 0f, 1f), 10f, dt);
        d.run = approach(d.run, MathHelper.clamp((d.speed - 4.7f) / 1.1f, 0f, 1f), 8f, dt);

        // --- воздух / приземление ---
        if (!d.onGround) { d.minVy = Math.min(d.minVy, d.vy); d.airTime += dt; }
        else {
            if (d.airTime > 0.15f) {
                float imp = MathHelper.clamp(-d.minVy / 16f, 0f, 1f);
                if (imp > 0.15f) d.squat = Math.max(d.squat, imp);
            }
            d.airTime = 0; d.minVy = 0;
        }
        d.squat = Math.max(0f, d.squat - dt * 4.5f);
        float airTarget = (d.active && d.airTime > 0.12f) ? 1f : 0f;
        d.air = approach(d.air, airTarget, airTarget > 0 ? 14f : 18f, dt);
        if (d.airTime < 0.12f) d.leadRight = Math.cos(st.limbSwingAnimationProgress * 0.6662f) < 0; // какая нога была впереди при отрыве

        // --- поворот на месте ---
        float standT = (d.active && d.onGround && d.speed < 0.6f && Math.abs(d.yawRate) > 20f) ? 1f : 0f;
        d.standTurn = approach(d.standTurn, standT, 10f, dt);

        // --- окружение ---
        MinecraftClient mc = MinecraftClient.getInstance();
        World w = mc.world;
        boolean near = w != null && mc.player != null && p.squaredDistanceTo(mc.player) < 32 * 32 && d.active;

        float yaw = st.bodyYaw * MathHelper.RADIANS_PER_DEGREE;
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);   // вперёд
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);  // вправо (от лица игрока)

        float tR = 0, tL = 0, wR = 0, wL = 0;
        if (near) {
            if (c.footIk && d.onGround) {
                float ph = st.limbSwingAnimationProgress * 0.6662f;
                float amp = Math.min(1f, st.limbSwingAmplitude);
                float pitchR = (float) Math.cos(ph) * 1.2f * amp;   // положительный = нога назад
                double offR = -Math.sin(pitchR) * 0.7, offL = Math.sin(pitchR) * 0.7;
                tR = footTarget(w, p, pos.x + rx * 0.125 + fx * offR, pos.y, pos.z + rz * 0.125 + fz * offR);
                tL = footTarget(w, p, pos.x - rx * 0.125 + fx * offL, pos.y, pos.z - rz * 0.125 + fz * offL);
            }
            if (c.wallArms) {
                wR = wall(w, p, pos, rx, rz);
                wL = wall(w, p, pos, -rx, -rz);
            }
        }
        d.footR = approach(d.footR, tR, 16f, dt);
        d.footL = approach(d.footL, tL, 16f, dt);
        d.wallR = approach(d.wallR, wR, 14f, dt);
        d.wallL = approach(d.wallL, wL, 14f, dt);
        return d;
    }

    /** Высота земли под точкой минус высота ног игрока, в блоках. */
    private static float footTarget(World w, Entity e, double x, double y, double z) {
        Vec3d a = new Vec3d(x, y + 0.6, z), b = new Vec3d(x, y - 1.0, z);
        BlockHitResult r = w.raycast(new RaycastContext(a, b,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, e));
        if (r.getType() == HitResult.Type.MISS) return 0f;
        float o = (float) (r.getPos().y - y);
        if (o < -0.75f) return 0f;                // обрыв: ногу не тянем
        return MathHelper.clamp(o, -0.5f, 0.3f);
    }

    /** 0..1: насколько близко стена сбоку от руки. */
    private static float wall(World w, Entity e, Vec3d pos, double sx, double sz) {
        float min = 0.9f;
        for (double hy : new double[]{1.15, 0.6}) {
            Vec3d a = new Vec3d(pos.x, pos.y + hy, pos.z);
            Vec3d b = a.add(sx * 0.9, 0, sz * 0.9);
            BlockHitResult r = w.raycast(new RaycastContext(a, b,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, e));
            if (r.getType() != HitResult.Type.MISS) min = Math.min(min, (float) a.distanceTo(r.getPos()));
        }
        return MathHelper.clamp((0.62f - min) / 0.27f, 0f, 1f);
    }

    static float approach(float cur, float target, float rate, float dt) {
        return cur + (target - cur) * (1f - (float) Math.exp(-rate * dt));
    }
}
