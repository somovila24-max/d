package com.fluentmotion;

public interface AnimHolder {
    AnimData fluentmotion$getData();
    void fluentmotion$setData(AnimData data);
}
