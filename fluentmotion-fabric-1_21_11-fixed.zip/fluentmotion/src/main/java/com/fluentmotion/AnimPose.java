package com.fluentmotion;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.util.math.MathHelper;

/**
 * Накладывает новую анимацию поверх ванильной позы модели.
 * Единицы origin* — пиксели модели (1/16 блока), +Y вниз, +Z назад.
 * pitch>0: часть отклоняется назад, pitch<0: вперёд.
 */
public final class AnimPose {
    private static final float LEG = 12f; // длина ноги в пикселях

    public static void apply(BipedEntityModel<?> m, PlayerEntityRenderState st, AnimData d) {
        AnimConfig c = AnimConfig.C;
        if (!c.enabled || !d.active) return;

        float gw = (c.gait && !d.sneaking) ? 1f : 0f;
        float air = c.jumping ? d.air : 0f;
        float gnd = 1f - air;
        float run = d.run * gw * gnd;
        float mv = d.move * gw * gnd;

        ModelPart rl = m.rightLeg, ll = m.leftLeg, ra = m.rightArm, la = m.leftArm, body = m.body;

        boolean armsFree = d.swing <= 0.001f && !d.usingItem;
        boolean rFree = armsFree && free(st.rightArmPose);
        boolean lFree = armsFree && free(st.leftArmPose);

        // ---------- 1. Ходьба / бег ----------
        if (gw > 0f) {
            rl.pitch = gaitLeg(rl.pitch, run);
            ll.pitch = gaitLeg(ll.pitch, run);
        }
        float maxA = Math.min(1.3f, Math.max(Math.abs(rl.pitch), Math.abs(ll.pitch)));
        float dip = LEG * (1f - MathHelper.cos(maxA)) * c.gaitDip * mv;   // ступни касаются земли в фазе шага

        float phi = 0.05f * mv + 0.28f * run + d.squat * 0.35f * gnd;      // наклон вперёд
        float rho = c.turning ? -MathHelper.clamp(d.yawRate / 270f, -1f, 1f) * 0.2f * mv : 0f; // крен в повороте
        body.pitch += phi;
        body.roll += rho;
        float legDx = -LEG * MathHelper.sin(rho);
        float legDy = -LEG * (1f - MathHelper.cos(phi)) - LEG * (1f - MathHelper.cos(rho));
        float legDz = LEG * MathHelper.sin(phi);
        rl.originX += legDx; ll.originX += legDx;
        rl.originY += legDy; ll.originY += legDy;
        rl.originZ += legDz; ll.originZ += legDz;

        if (rFree) {
            ra.pitch = ra.pitch * (1f + 0.2f * run) - 0.30f * run;
            ra.roll -= 0.10f * run;
        }
        if (lFree) {
            la.pitch = la.pitch * (1f + 0.2f * run) - 0.30f * run;
            la.roll += 0.10f * run;
        }

        // ---------- 2. Повороты на месте ----------
        if (c.turning && d.standTurn > 0.001f) {
            float s = d.standTurn;
            float lag = -MathHelper.clamp(d.yawRate / 360f, -1f, 1f) * 0.55f * s;   // ноги отстают от корпуса
            rl.yaw += lag; ll.yaw += lag;
            float sp = MathHelper.sin(d.turnPhase);
            rl.pitch += -0.45f * s * Math.max(0f, sp);
            ll.pitch += -0.45f * s * Math.max(0f, -sp);
        }

        // ---------- 3. Прыжок / падение ----------
        if (air > 0.001f) {
            float u = MathHelper.clamp(d.vy / 8f, -1f, 1f);    // +1 взлёт, -1 падение
            float s = (u + 1f) * 0.5f;
            float stride = MathHelper.clamp(d.speed / 3f, 0f, 1f);

            float leadRise = -(0.5f + 0.5f * stride), trailRise = MathHelper.lerp(stride, -0.25f, 0.7f);
            float lead = MathHelper.lerp(s, -0.35f, leadRise);
            float trail = MathHelper.lerp(s, 0.3f, trailRise);
            float rT = d.leadRight ? lead : trail, lT = d.leadRight ? trail : lead;
            rl.pitch = MathHelper.lerp(air, rl.pitch, rT);
            ll.pitch = MathHelper.lerp(air, ll.pitch, lT);
            rl.roll += 0.12f * (1f - s) * air;
            ll.roll -= 0.12f * (1f - s) * air;

            // руки: взлёт — маховые вверх, падение — в стороны
            float armFwd = -1.15f, armBack = MathHelper.lerp(stride, -1.15f, 0.6f);
            float armRiseR = d.leadRight ? armBack : armFwd;       // рука противоположна ведущей ноге
            float armRiseL = d.leadRight ? armFwd : armBack;
            float armFall = -0.25f;
            float rollOut = MathHelper.lerp(s, 1.0f, 0.15f);
            if (rFree) {
                ra.pitch = MathHelper.lerp(air, ra.pitch, MathHelper.lerp(s, armFall, armRiseR));
                ra.roll = MathHelper.lerp(air, ra.roll, rollOut);
            }
            if (lFree) {
                la.pitch = MathHelper.lerp(air, la.pitch, MathHelper.lerp(s, armFall, armRiseL));
                la.roll = MathHelper.lerp(air, la.roll, -rollOut);
            }
        }

        // ---------- 4. Приземление ----------
        float squatDrop = 0f;
        if (d.squat > 0.001f && c.jumping) {
            float sq = d.squat * gnd;
            rl.pitch -= 0.8f * sq; ll.pitch -= 0.8f * sq;
            squatDrop = LEG * (1f - MathHelper.cos(0.8f * sq)) * 0.9f;
            if (rFree) ra.pitch -= 0.6f * sq;
            if (lFree) la.pitch -= 0.6f * sq;
        }

        // ---------- 5. IK ног по высоте блоков ----------
        float drop = 0f;
        if (c.footIk) {
            float ik = c.footIkStrength * (1f - 0.5f * run) * gnd;
            float diff = -Math.min(0f, Math.min(d.footR, d.footL));                // блоки
            drop = diff * 16f * c.pelvisFactor * ik;                                // таз вниз, px
            rl.pitch -= liftAngle(Math.max(0f, drop + d.footR * 16f * ik), c);
            ll.pitch -= liftAngle(Math.max(0f, drop + d.footL * 16f * ik), c);
        }

        // ---------- 6. Стены: рука прижимается, тело отодвигается ----------
        float shiftX = 0f;
        if (c.wallArms) {
            shiftX = (d.wallR - d.wallL) * c.wallBodyShiftPx;      // от правой стены = +X модели
            ra.originX += d.wallR * c.wallArmTuckPx;
            la.originX -= d.wallL * c.wallArmTuckPx;
            if (rFree) {
                ra.pitch *= 1f - 0.5f * d.wallR;
                ra.roll -= 0.12f * d.wallR;
                ra.pitch -= 0.2f * d.wallR * run;
            }
            if (lFree) {
                la.pitch *= 1f - 0.5f * d.wallL;
                la.roll += 0.12f * d.wallL;
                la.pitch -= 0.2f * d.wallL * run;
            }
        }

        // ---------- 7. Сдвиг всей модели (таз вниз, тело от стены) ----------
        float dy = dip * gnd + drop + squatDrop;
        shift(m, shiftX, dy);
    }

    private static float gaitLeg(float v, float run) {
        v *= 1f + 0.15f * run;
        if (v > 0f) v *= 1f + 0.30f * run;     // задняя нога сильнее отходит назад
        return v;
    }

    /** Угол выноса ноги вперёд, чтобы её стопа поднялась на raisePx. */
    private static float liftAngle(float raisePx, AnimConfig c) {
        if (raisePx <= 0f) return 0f;
        float a = (float) Math.acos(MathHelper.clamp(1f - raisePx / LEG, -1f, 1f));
        return Math.min(a, (float) Math.toRadians(c.maxLegLiftDeg));
    }

    private static boolean free(BipedEntityModel.ArmPose p) {
        return p == BipedEntityModel.ArmPose.EMPTY || p == BipedEntityModel.ArmPose.ITEM;
    }

    private static void shift(BipedEntityModel<?> m, float dx, float dy) {
        for (ModelPart p : new ModelPart[]{m.head, m.body, m.rightArm, m.leftArm, m.rightLeg, m.leftLeg}) {
            p.originX += dx;
            p.originY += dy;
        }
    }
}
