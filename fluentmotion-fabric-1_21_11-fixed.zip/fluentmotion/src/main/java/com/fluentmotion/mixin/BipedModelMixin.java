package com.fluentmotion.mixin;

import com.fluentmotion.AnimData;
import com.fluentmotion.AnimHolder;
import com.fluentmotion.AnimPose;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Работает и для модели игрока, и для моделей брони (они тоже BipedEntityModel), чтобы броня двигалась вместе с телом. */
@Mixin(BipedEntityModel.class)
public abstract class BipedModelMixin {
    @Inject(method = "setAngles(Lnet/minecraft/client/render/entity/state/BipedEntityRenderState;)V", at = @At("TAIL"))
    private void fluentmotion$apply(BipedEntityRenderState state, CallbackInfo ci) {
        if (state instanceof PlayerEntityRenderState ps) {
            AnimData d = ((AnimHolder) ps).fluentmotion$getData();
            if (d != null) AnimPose.apply((BipedEntityModel<?>) (Object) this, ps, d);
        }
    }
}
