package com.fluentmotion.mixin;

import com.fluentmotion.AnimData;
import com.fluentmotion.AnimHolder;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(PlayerEntityRenderState.class)
public class PlayerStateMixin implements AnimHolder {
    @Unique private AnimData fluentmotion$data;

    @Override public AnimData fluentmotion$getData() { return fluentmotion$data; }
    @Override public void fluentmotion$setData(AnimData data) { this.fluentmotion$data = data; }
}
