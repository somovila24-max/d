package com.fluentmotion;

/** Сглаженное состояние анимации одного игрока. */
public final class AnimData {
    public boolean active, sneaking, onGround, usingItem, leadRight = true;
    public float swing;

    public float speed, vy, yawRate;       // блоки/с, блоки/с, градусы/с
    public float move, run;                // 0..1
    public float footL, footR;             // высота земли под ногой относительно ног игрока, блоки
    public float wallL, wallR;             // 0..1 близость стены сбоку
    public float air, squat, standTurn, turnPhase, airTime, minVy;

    public double lx, ly, lz;
    public float lastYaw;
    public long lastNanos, lastSeen;
}
