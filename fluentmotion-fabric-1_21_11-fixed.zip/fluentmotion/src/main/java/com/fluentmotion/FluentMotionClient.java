package com.fluentmotion;

import net.fabricmc.api.ClientModInitializer;

public class FluentMotionClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        AnimConfig.load();
    }
}
